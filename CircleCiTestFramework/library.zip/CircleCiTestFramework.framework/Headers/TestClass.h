//
//  TestClass.h
//  CircleCiTestFramework
//
//  Created by Marcelo Santos on 15/01/18.
//  Copyright © 2018 Marcelo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestClass : NSObject

- (NSString*) testMethod;
    
@end
