//
//  CircleCiTestFramework.h
//  CircleCiTestFramework
//
//  Created by Marcelo Santos on 15/01/18.
//  Copyright © 2018 Marcelo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CircleCiTestFramework.
FOUNDATION_EXPORT double CircleCiTestFrameworkVersionNumber;

//! Project version string for CircleCiTestFramework.
FOUNDATION_EXPORT const unsigned char CircleCiTestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CircleCiTestFramework/PublicHeader.h>


